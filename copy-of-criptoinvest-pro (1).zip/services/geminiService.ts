
import { GoogleGenAI, Type } from "@google/genai";
import { RiskReturnAnalysis, CryptoData } from '../types';

// FIX: Initialize GoogleGenAI directly with the environment variable as per guidelines.
// This assumes process.env.API_KEY is properly configured in the environment.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const analysisSchema = {
    type: Type.OBJECT,
    properties: {
      nivelDeRisco: {
        type: Type.STRING,
        description: "O nível de risco do investimento, categorizado como 'Baixo', 'Médio' ou 'Alto'.",
      },
      potencialDeRetorno: {
        type: Type.STRING,
        description: "O potencial de retorno do investimento, categorizado como 'Baixo', 'Médio' ou 'Alto'.",
      },
      analise: {
        type: Type.STRING,
        description: "Uma análise detalhada em 3-4 frases sobre os fatores de risco e retorno, justificando as classificações.",
      },
    },
    required: ["nivelDeRisco", "potencialDeRetorno", "analise"],
};

export const analyzeCryptoRiskReturn = async (crypto: CryptoData): Promise<RiskReturnAnalysis> => {
  try {
    const prompt = `Como um analista de investimentos experiente, analise o risco e o retorno para a criptomoeda ${crypto.name} (${crypto.symbol}). O preço atual é aproximadamente $${crypto.price.toFixed(2)} e a capitalização de mercado é de ${crypto.marketCap}. Considere a volatilidade histórica (simulada), o volume de negociação e o sentimento geral do mercado de criptoativos. Forneça uma análise concisa, profissional e direta para um investidor, usando o schema JSON fornecido.`;
    
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: analysisSchema,
      },
    });

    const jsonText = response.text.trim();
    const analysisData = JSON.parse(jsonText);
    
    return analysisData;

  } catch (error) {
    console.error("Erro ao buscar análise do Gemini API:", error);
    throw new Error("Não foi possível se comunicar com o serviço de IA.");
  }
};
