import React from 'react';
import { CryptoData } from '../types';
import { ResponsiveContainer, LineChart, Line } from 'recharts';

interface CryptoCardProps {
  crypto: CryptoData;
  isSelected: boolean;
  onSelect: () => void;
}

const CryptoCard: React.FC<CryptoCardProps> = ({ crypto, isSelected, onSelect }) => {
  const isPositive = crypto.change24h >= 0;
  const changeColor = isPositive ? 'text-green-500' : 'text-red-500';
  const sparklineColor = isPositive ? '#22c55e' : '#ef4444';

  const selectedClasses = isSelected
    ? 'ring-2 ring-cyan-400 scale-105 shadow-cyan-500/30'
    : 'ring-1 ring-slate-700 hover:ring-cyan-500';

  return (
    <div
      onClick={onSelect}
      className={`bg-slate-800 p-4 rounded-lg cursor-pointer transition-all duration-300 shadow-lg hover:shadow-xl flex flex-col justify-between ${selectedClasses}`}
    >
      <div className="flex items-center justify-between">
        <div>
          <p className="text-lg font-bold text-white">{crypto.name}</p>
          <p className="text-sm text-gray-400">{crypto.symbol}</p>
        </div>
        <div className={`w-10 h-10 rounded-full flex items-center justify-center bg-slate-700 font-bold text-white`}>
            {crypto.symbol}
        </div>
      </div>

      <div className="h-12 w-full my-2">
        <ResponsiveContainer width="100%" height="100%">
            <LineChart data={crypto.history}>
                <Line 
                    type="monotone" 
                    dataKey="price" 
                    stroke={sparklineColor} 
                    strokeWidth={2} 
                    dot={false} 
                />
            </LineChart>
        </ResponsiveContainer>
      </div>
      
      <div className="text-right">
        <p className="text-xl font-semibold text-white">${crypto.price.toLocaleString('en-US')}</p>
        <p className={`text-md font-medium ${changeColor}`}>
          {isPositive ? '+' : ''}
          {crypto.change24h.toFixed(2)}%
        </p>
      </div>
    </div>
  );
};

export default CryptoCard;