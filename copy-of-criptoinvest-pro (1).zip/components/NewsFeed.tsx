
import React, { useState, useEffect } from 'react';
import { CryptoData, RiskReturnAnalysis } from '../types';
import { analyzeCryptoRiskReturn } from '../services/geminiService';
import LoadingSpinner from './LoadingSpinner';

interface RiskReturnAnalyzerProps {
  selectedCrypto: CryptoData | null;
}

const RiskReturnAnalyzer: React.FC<RiskReturnAnalyzerProps> = ({ selectedCrypto }) => {
  const [analysis, setAnalysis] = useState<RiskReturnAnalysis | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    setAnalysis(null);
    setError(null);
  }, [selectedCrypto]);

  const handleAnalyze = async () => {
    if (!selectedCrypto) return;
    setLoading(true);
    setError(null);
    setAnalysis(null);
    try {
      const result = await analyzeCryptoRiskReturn(selectedCrypto);
      setAnalysis(result);
    } catch (err) {
      setError('Falha ao gerar análise. Tente novamente.');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const getRiskColor = (level: string = '') => {
    switch (level.toLowerCase()) {
      case 'alto': return 'text-red-400';
      case 'médio': return 'text-yellow-400';
      case 'baixo': return 'text-green-400';
      default: return 'text-gray-400';
    }
  };

  const getReturnColor = (level: string = '') => {
    switch (level.toLowerCase()) {
      case 'alto': return 'text-green-400';
      case 'médio': return 'text-yellow-400';
      case 'baixo': return 'text-red-400';
      default: return 'text-gray-400';
    }
  };


  return (
    <div className="bg-slate-800 p-4 sm:p-6 rounded-lg shadow-lg h-full">
      <h2 className="text-2xl font-bold text-white mb-4">Análise com IA</h2>
      {!selectedCrypto ? (
        <div className="text-center text-gray-400 py-10">
            <p>Selecione uma criptomoeda no painel para analisar.</p>
        </div>
      ) : (
        <>
            <p className="text-gray-400 mb-4">
                Analisando: <span className="font-bold text-cyan-400">{selectedCrypto.name}</span>
            </p>
            <button
                onClick={handleAnalyze}
                disabled={loading}
                className="w-full bg-cyan-500 text-white font-bold py-2 px-4 rounded-lg hover:bg-cyan-600 disabled:bg-slate-600 transition-colors duration-300 flex items-center justify-center"
            >
                {loading ? <LoadingSpinner size="sm" /> : 'Analisar Risco e Retorno'}
            </button>

            {error && <p className="text-red-500 mt-4 text-center">{error}</p>}
            
            <div className="mt-6 space-y-4">
                {!analysis && !loading && (
                    <div className="text-center text-gray-400 py-10">
                        <p>Clique no botão para gerar uma análise de risco e potencial de retorno para {selectedCrypto.name} usando a IA do Gemini.</p>
                    </div>
                )}
                {analysis && (
                    <div className="bg-slate-700/50 p-4 rounded-md space-y-4 animate-fade-in">
                        <div>
                            <h3 className="font-semibold text-gray-300 text-sm">Nível de Risco</h3>
                            <p className={`text-lg font-bold ${getRiskColor(analysis.nivelDeRisco)}`}>{analysis.nivelDeRisco || 'N/A'}</p>
                        </div>
                        <div>
                            <h3 className="font-semibold text-gray-300 text-sm">Potencial de Retorno</h3>
                            <p className={`text-lg font-bold ${getReturnColor(analysis.potencialDeRetorno)}`}>{analysis.potencialDeRetorno || 'N/A'}</p>
                        </div>
                        <div>
                            <h3 className="font-semibold text-gray-300 text-sm">Análise Resumida</h3>
                            <p className="text-gray-300 mt-1 text-sm">{analysis.analise}</p>
                        </div>
                    </div>
                )}
            </div>
        </>
      )}
    </div>
  );
};

export default RiskReturnAnalyzer;
