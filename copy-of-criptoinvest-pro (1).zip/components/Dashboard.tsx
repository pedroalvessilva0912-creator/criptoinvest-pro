
import React from 'react';
import { CryptoData } from '../types';
import CryptoChart from './CryptoChart';
import CryptoCard from './CryptoCard';

interface DashboardProps {
  cryptos: CryptoData[];
  selectedCrypto: CryptoData | null;
  onCryptoSelect: (crypto: CryptoData) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ cryptos, selectedCrypto, onCryptoSelect }) => {
  return (
    <div className="space-y-8">
      {selectedCrypto && (
        <div className="bg-slate-800 p-4 sm:p-6 rounded-lg shadow-lg">
          <h2 className="text-2xl sm:text-3xl font-bold text-white mb-2">{selectedCrypto.name} ({selectedCrypto.symbol})</h2>
          <p className="text-3xl sm:text-4xl font-semibold text-white">${selectedCrypto.price.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
          <div className="h-80 sm:h-96 w-full mt-4">
            <CryptoChart data={selectedCrypto.history} color={selectedCrypto.color} />
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {cryptos.map((crypto) => (
          <CryptoCard
            key={crypto.id}
            crypto={crypto}
            isSelected={selectedCrypto?.id === crypto.id}
            onSelect={() => onCryptoSelect(crypto)}
          />
        ))}
      </div>
    </div>
  );
};

export default Dashboard;
