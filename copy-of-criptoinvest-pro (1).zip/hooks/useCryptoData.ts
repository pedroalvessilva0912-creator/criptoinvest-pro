import { useState, useEffect } from 'react';
import { CryptoData, HistoricalData } from '../types';

const COIN_IDS = ['bitcoin', 'ethereum', 'solana', 'cardano', 'ripple', 'dogecoin'];

const COIN_COLORS: { [key: string]: string } = {
  bitcoin: '#f7931a',
  ethereum: '#627eea',
  solana: '#9945FF',
  cardano: '#0033ad',
  ripple: '#00aae4',
  dogecoin: '#c2a633',
};

// Função para gerar um histórico de preços simulado e mais realista
const generateMockHistory = (basePrice: number, days = 30): HistoricalData[] => {
  const history: HistoricalData[] = [];
  let price = basePrice;
  const today = new Date();

  for (let i = 0; i < days; i++) {
    const date = new Date(today);
    date.setDate(today.getDate() - (days - 1 - i));
    const volatility = (Math.random() - 0.45) * 0.1; // Simula a volatilidade diária
    price *= (1 + volatility);
    history.push({
      date: date.toLocaleDateString('pt-BR', { month: 'short', day: 'numeric' }),
      price: parseFloat(price.toFixed(2)),
    });
  }
  return history;
};

// Dados simulados para garantir que o app funcione sem depender de APIs externas
const MOCK_DATA: CryptoData[] = [
  {
    id: 'bitcoin',
    name: 'Bitcoin',
    symbol: 'BTC',
    price: 67500.82,
    change24h: 1.5,
    marketCap: '1.3T',
    volume24h: '25.5B',
    color: COIN_COLORS.bitcoin,
    history: generateMockHistory(65000),
  },
  {
    id: 'ethereum',
    name: 'Ethereum',
    symbol: 'ETH',
    price: 3500.45,
    change24h: -0.8,
    marketCap: '420B',
    volume24h: '15.2B',
    color: COIN_COLORS.ethereum,
    history: generateMockHistory(3600),
  },
  {
    id: 'solana',
    name: 'Solana',
    symbol: 'SOL',
    price: 150.1,
    change24h: 3.2,
    marketCap: '69B',
    volume24h: '3.1B',
    color: COIN_COLORS.solana,
    history: generateMockHistory(140),
  },
  {
    id: 'cardano',
    name: 'Cardano',
    symbol: 'ADA',
    price: 0.45,
    change24h: -2.1,
    marketCap: '16B',
    volume24h: '500M',
    color: COIN_COLORS.cardano,
    history: generateMockHistory(0.48),
  },
  {
    id: 'ripple',
    name: 'Ripple',
    symbol: 'XRP',
    price: 0.52,
    change24h: 0.5,
    marketCap: '28B',
    volume24h: '1.2B',
    color: COIN_COLORS.ripple,
    history: generateMockHistory(0.51),
  },
  {
    id: 'dogecoin',
    name: 'Dogecoin',
    symbol: 'DOGE',
    price: 0.15,
    change24h: 5.8,
    marketCap: '21B',
    volume24h: '900M',
    color: COIN_COLORS.dogecoin,
    history: generateMockHistory(0.13),
  },
];


const useCryptoData = () => {
  const [cryptos, setCryptos] = useState<CryptoData[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const loadMockData = () => {
      setLoading(true);
      setError(null);
      // Simula uma pequena latência de rede
      setTimeout(() => {
        try {
          setCryptos(MOCK_DATA);
        } catch (err) {
            setError('Falha ao carregar os dados simulados.');
            console.error(err);
        } finally {
          setLoading(false);
        }
      }, 500);
    };

    loadMockData();
  }, []);

  return { cryptos, loading, error };
};

export default useCryptoData;